let socket = null;
let currentUser = { name: "Guest", isHost: false };
let controlMode = "host_only";
let lastHostState = { time: 0, paused: true };
let heartbeatInterval = null;
let isSidebarHidden = false;

// Safely escapes malicious characters from user input
function escapeHTML(str) {
  if (!str) return "";
  return String(str).replace(
    /[&<>'"]/g,
    (tag) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "'": "&#39;",
        '"': "&quot;",
      })[tag] || tag,
  );
}

// Inject Custom CSS for Marquee Animations & Scrollbars
if (!document.getElementById("sk-custom-styles")) {
  const style = document.createElement("style");
  style.id = "sk-custom-styles";
  style.innerHTML = `
    @keyframes sk-marquee-anim {
      from { left: 100vw; transform: translateX(0); }
      to { left: -100%; transform: translateX(-100%); }
    }
    .sk-marquee-text {
      position: fixed; color: #ffffff; font-size: 28px; font-weight: 900;
      font-family: sans-serif; white-space: nowrap; z-index: 2147483647; pointer-events: none;
      text-shadow: -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000, 2px 2px 0 #000, -3px 0 0 #000, 3px 0 0 #000, 0 -3px 0 #000, 0 3px 0 #000, 4px 4px 5px rgba(0,0,0,0.5);
      animation: sk-marquee-anim 15s linear forwards;
    }
    #sk-chat-messages::-webkit-scrollbar, .sk-scroll::-webkit-scrollbar { width: 4px; }
    #sk-chat-messages::-webkit-scrollbar-thumb, .sk-scroll::-webkit-scrollbar-thumb { background: #444; border-radius: 4px; }
  `;
  document.head.appendChild(style);
}

function getColorFromName(name) {
  let hash = 0;
  for (let i = 0; i < name.length; i++)
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  const h = Math.abs(hash) % 360;
  return `hsl(${h}, 70%, 50%)`;
}

function getAvatarHTML(name, isHost) {
  const color = getColorFromName(name);
  const initial = name.charAt(0).toUpperCase();
  const hostBadge = isHost
    ? `<div style="position: absolute; bottom: -2px; right: -4px; font-size: 10px; background: #111; border-radius: 50%; width: 14px; height: 14px; display: flex; align-items: center; justify-content: center; border: 1px solid #333;">👑</div>`
    : "";

  return `
    <div style="position: relative; width: 28px; height: 28px; flex-shrink: 0;">
      <div style="width: 100%; height: 100%; border-radius: 50%; background: ${color}; color: white; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: bold; border: 2px solid rgba(255,255,255,0.1); box-sizing: border-box;">
        ${initial}
      </div>
      ${hostBadge}
    </div>
  `;
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "TOGGLE_SIDEBAR" && window.self === window.top) {
    initSidebar();
  }
});

function initSidebar(autoJoinRoom = null) {
  document.body.style.width = "calc(100% - 340px)";
  document.body.style.position = "absolute";
  document.body.style.left = "0";
  isSidebarHidden = false;

  let existingSidebar = document.getElementById("synkingg-sidebar");
  if (existingSidebar) {
    existingSidebar.style.display = "flex";
    document.getElementById("sk-floating-btn").style.display = "none";
    return;
  }

  const floatingBtn = document.createElement("button");
  floatingBtn.id = "sk-floating-btn";
  floatingBtn.type = "button";
  floatingBtn.innerHTML = "👑";
  floatingBtn.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    background: #E50914; color: white; border: 2px solid #fff; border-radius: 50%; 
    width: 50px; height: 50px; font-size: 20px; cursor: pointer; display: none; 
    box-shadow: 0 4px 10px rgba(0,0,0,0.5); transition: transform 0.2s;
  `;
  document.body.appendChild(floatingBtn);

  const sidebar = document.createElement("div");
  sidebar.id = "synkingg-sidebar";
  sidebar.style.cssText = `
    position: fixed; top: 0; right: 0; width: 340px; height: 100vh;
    background: #111; color: white; z-index: 2147483647; padding: 15px;
    box-shadow: -5px 0 15px rgba(0,0,0,0.8); font-family: sans-serif;
    display: flex; flex-direction: column; gap: 15px; box-sizing: border-box;
  `;

  sidebar.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #333; padding-bottom: 10px;">
      <h2 style="margin: 0; font-size: 18px;">👑 SynKingg</h2>
      <button type="button" id="sk-login-btn" style="background: #E50914; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: bold;">
  Log In / Sign Up
</button>
      <div style="display: flex; gap: 10px;">
        <button type="button" id="sk-fullscreen-btn" title="Fullscreen" style="background: none; border: none; color: #aaa; cursor: pointer; font-size: 18px;">⛶</button>
        <button type="button" id="sk-settings-btn" title="Settings" style="background: none; border: none; color: #aaa; cursor: pointer; font-size: 18px;">⚙️</button>
        <button type="button" id="sk-minimize-btn" title="Minimize UI" style="background: none; border: none; color: #E50914; cursor: pointer; font-size: 18px; font-weight: bold; transform: translateY(-3px);">_</button>
      </div>
    </div>

    <div id="sk-settings-panel" style="display: none; background: #222; padding: 15px; border-radius: 4px; flex-direction: column; gap: 15px;">
      <div>
        <p style="margin: 0 0 5px 0; font-size: 11px; color: #aaa;">CHANGE NAME</p>
        <div style="display: flex; gap: 5px;">
          <input id="sk-new-name" placeholder="New Name" style="flex-grow: 1; padding: 8px; border-radius: 4px; border: none;" />
          <button type="button" id="sk-save-name-btn" style="padding: 8px; background: #E50914; color: white; border: none; cursor: pointer; border-radius: 4px;">Save</button>
        </div>
      </div>
      <div id="sk-host-controls" style="display: none; flex-direction: column; gap: 5px; border-top: 1px solid #444; padding-top: 10px;">
        <p style="margin: 0; font-size: 11px; color: #E50914; font-weight: bold;">ROOM CONTROL (HOST ONLY)</p>
        <select id="sk-control-mode" style="padding: 8px; border-radius: 4px; border: none; background: #111; color: white; outline: none;">
          <option value="host_only">Only Host Can Control</option>
          <option value="everyone">Everyone Can Control</option>
        </select>
      </div>
    </div>

    <div id="sk-setup-view" style="display: flex; flex-direction: column; gap: 15px;">
      <input id="sk-username" placeholder="Enter Your Name" style="padding: 10px; border-radius: 4px; border: none; text-align: center;" />
      <button type="button" id="sk-host-btn" style="padding: 12px; background: #E50914; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: bold;">Create Room (Host)</button>
      <button type="button" id="sk-auto-join-btn" style="display: ${autoJoinRoom ? "block" : "none"}; padding: 12px; background: #333; color: white; border: 1px solid #555; cursor: pointer; border-radius: 4px;">Join Room ${autoJoinRoom}</button>
    </div>

    <div id="sk-active-view" style="display: none; flex-direction: column; gap: 15px; flex-grow: 1; overflow: hidden;">
      <p id="sk-status" style="color: #4CAF50; font-size: 12px; text-align: center; margin: 0;">✅ Connected</p>
      
      <div id="sk-share-container" style="background: #222; padding: 10px; border-radius: 4px; display: flex; flex-direction: column; gap: 8px;">
        <input id="sk-share-link" readonly style="padding: 6px; border-radius: 4px; border: 1px solid #444; background: #000; color: #fff; font-size: 11px; text-align: center;" />
        <button type="button" id="sk-copy-btn" style="padding: 6px; background: #333; color: white; border: none; cursor: pointer; border-radius: 4px; font-size: 12px;">Copy Invite Link</button>
      </div>

      <div class="sk-scroll" style="background: #222; border-radius: 4px; padding: 10px; max-height: 120px; overflow-y: auto;">
        <p style="margin: 0 0 5px 0; color: #aaa; font-size: 11px; border-bottom: 1px solid #444; padding-bottom: 3px;">MEMBERS</p>
        <ul id="sk-member-list" style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 8px; font-size: 13px;"></ul>
      </div>

      <div style="flex-grow: 1; background: #222; border-radius: 4px; display: flex; flex-direction: column; overflow: hidden;">
        <div id="sk-chat-messages" style="flex-grow: 1; padding: 10px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; font-size: 13px;">
          <div style="color: #888; text-align: center; font-size: 11px;">Welcome to the chat!</div>
        </div>
        <div style="display: flex; border-top: 1px solid #444;">
          <input id="sk-chat-input" placeholder="Type a message..." autocomplete="off" style="flex-grow: 1; padding: 10px; border: none; background: #111; color: white; outline: none;" />
          <button type="button" id="sk-chat-send" style="padding: 10px 15px; background: #333; color: white; border: none; cursor: pointer;">➤</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(sidebar);

  // --- UI EVENT LISTENERS ---


  // content.js - Listen for the login from the website
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.sk_token && changes.sk_token.newValue) {
    // The user just logged in!
    const newUsername = changes.sk_username.newValue;
    const newAvatar = changes.sk_avatar.newValue;
    
    // 1. Update the local user object
    currentUser.name = newUsername;
    currentUser.avatar = newAvatar;
    
    // 2. Hide the Login button, maybe show their Avatar in the top right
    document.getElementById('sk-login-btn').style.display = 'none';
    
    // 3. Tell the WebSocket Server that we are authenticated now
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ 
        type: 'UPDATE_PROFILE', 
        token: changes.sk_token.newValue 
      }));
    }
    
    addSysMsg(`Successfully logged in as ${newUsername}!`);
  }
});

// Check if they are already logged in when the page loads
chrome.storage.local.get(['sk_token', 'sk_username', 'sk_avatar'], (data) => {
  if (data.sk_token) {
    currentUser.name = data.sk_username;
    currentUser.avatar = data.sk_avatar;
    document.getElementById('sk-login-btn').style.display = 'none';
  }
});


  // Fullscreen Logic
  document
    .getElementById("sk-fullscreen-btn")
    .addEventListener("click", (e) => {
      e.preventDefault();
      if (!document.fullscreenElement) {
        document.documentElement
          .requestFullscreen()
          .catch((err) => console.log(err));
      } else {
        document.exitFullscreen();
      }
    });

    document.getElementById('sk-login-btn').addEventListener('click', (e) => {
  e.preventDefault();
  // Change to your production URL later (e.g., https://synkingg.com/login)
  window.open('https://synkingg-hub.vercel.app/login', '_blank'); 
});

  document.getElementById("sk-minimize-btn").addEventListener("click", (e) => {
    e.preventDefault();
    sidebar.style.display = "none";
    floatingBtn.style.display = "block";
    isSidebarHidden = true;
    document.body.style.width = "";
    document.body.style.position = "";
    document.body.style.left = "";
  });

  floatingBtn.addEventListener("click", (e) => {
    e.preventDefault();
    floatingBtn.style.display = "none";
    sidebar.style.display = "flex";
    isSidebarHidden = false;
    document.body.style.width = "calc(100% - 340px)";
    document.body.style.position = "absolute";
    document.body.style.left = "0";
  });

  const spawnMarquee = (safeUsername, safeText, isHostFlag) => {
    const marquee = document.createElement("div");
    marquee.classList.add("sk-marquee-text");
    marquee.style.top = `${Math.floor(Math.random() * 13) + 2}%`;
    const nameColor = isHostFlag ? "#FF3B30" : "#4CD964";

    // Use the pre-sanitized variables here
    marquee.innerHTML = `<span style="color: ${nameColor}">${safeUsername}:</span> ${safeText}`;

    document.body.appendChild(marquee);
    setTimeout(() => marquee.remove(), 15000);
  };
  const addSysMsg = (txt) => {
    const m = document.getElementById("sk-chat-messages");
    m.innerHTML += `<div style="color: #FFB020; text-align: center; font-size: 11px; margin: 4px 0;">${txt}</div>`;
    m.scrollTop = m.scrollHeight;
  };

  const sPanel = document.getElementById("sk-settings-panel");
  document.getElementById("sk-settings-btn").addEventListener("click", (e) => {
    e.preventDefault();
    sPanel.style.display = sPanel.style.display === "none" ? "flex" : "none";
  });

  document.getElementById("sk-save-name-btn").addEventListener("click", (e) => {
    e.preventDefault();
    const nn = document.getElementById("sk-new-name").value.trim();
    if (nn && socket) {
      currentUser.name = nn;
      socket.send(JSON.stringify({ type: "UPDATE_NAME", newName: nn }));
      sPanel.style.display = "none";
    }
  });

  document.getElementById("sk-control-mode").addEventListener("change", (e) => {
    if (currentUser.isHost && socket) {
      socket.send(
        JSON.stringify({ type: "SETTINGS_UPDATE", mode: e.target.value }),
      );
      addSysMsg(
        `Room control changed to: ${e.target.value === "everyone" ? "Everyone" : "Host Only"}`,
      );
    }
  });

  document.getElementById("sk-host-btn")?.addEventListener("click", (e) => {
    e.preventDefault();
    startSync(
      Math.random().toString(36).substring(2, 8).toUpperCase(),
      document.getElementById("sk-username").value.trim() || "Host",
      true,
    );
  });

  document
    .getElementById("sk-auto-join-btn")
    ?.addEventListener("click", (e) => {
      e.preventDefault();
      startSync(
        autoJoinRoom,
        document.getElementById("sk-username").value.trim() || "Guest",
        false,
      );
    });

  document.getElementById("sk-copy-btn")?.addEventListener("click", (e) => {
    e.preventDefault();
    document.getElementById("sk-share-link").select();
    document.execCommand("copy");
    const btn = document.getElementById("sk-copy-btn");
    btn.innerText = "Copied! ✓";
    setTimeout(() => {
      btn.innerText = "Copy Invite Link";
    }, 2000);
  });

  function startSync(roomId, username, isHost) {
    currentUser = { name: username, isHost: isHost };
    document.getElementById("sk-setup-view").style.display = "none";
    document.getElementById("sk-active-view").style.display = "flex";

    if (isHost) {
      document.getElementById("sk-host-controls").style.display = "flex";
      const url = new URL(window.location.href);
      url.searchParams.set("sk_room", roomId);
      document.getElementById("sk-share-link").value = url.toString();
    } else {
      document.getElementById("sk-share-container").style.display = "none";
    }

    if (socket) socket.close();
    if (heartbeatInterval) clearInterval(heartbeatInterval);

    socket = new WebSocket(`wss://synkingg-hub.aaryanojha.partykit.dev/parties/main/${roomId}`);

    chrome.storage.local.set({
      sk_room: roomId,
      sk_user: username,
      sk_host: isHost,
    });

    const video = document.querySelector("video");

    if (video) {
      document.getElementById("sk-status").innerText = isHost
        ? "👑 Hosting (You have control)"
        : "👀 Watching";
      attachVideoListeners(video, socket, isHost, username);
    } else {
      document.getElementById("sk-status").innerText = "Searching for video...";
      const checkVideo = setInterval(() => {
        const v = document.querySelector("video");
        if (v) {
          clearInterval(checkVideo);
          document.getElementById("sk-status").innerText = isHost
            ? "👑 Hosting (You have control)"
            : "👀 Watching";
          attachVideoListeners(v, socket, isHost, username);
        }
      }, 1000);
    }

    const cInput = document.getElementById("sk-chat-input");
    const sendMsg = (e) => {
      if (e) e.preventDefault();
      if (cInput.value.trim() && socket) {
        socket.send(
          JSON.stringify({ type: "CHAT", text: cInput.value.trim() }),
        );
        cInput.value = "";
      }
    };
    document.getElementById("sk-chat-send").addEventListener("click", sendMsg);
    cInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") sendMsg(e);
    });

    socket.addEventListener("message", (event) => {
      const data = JSON.parse(event.data);

      if (data.type === "MEMBERS_UPDATE") {
        const listEl = document.getElementById("sk-member-list");
        listEl.innerHTML = "";
        data.members.forEach((m) => {
          listEl.innerHTML += `
            <li style="display: flex; align-items: center; gap: 8px;">
              ${getAvatarHTML(m.username, m.isHost)}
              <span style="color:${m.isHost ? "#FF3B30" : "#eee"}; font-weight:500;">${m.username}</span>
            </li>`;
        });
      }

      if (data.type === "CHAT") {
        const mDiv = document.getElementById("sk-chat-messages");

        // Sanitize inputs before injection
        const safeUsername = escapeHTML(data.username);
        const safeText = escapeHTML(data.text);

        mDiv.innerHTML += `
    <div style="display: flex; gap: 8px; align-items: flex-start;">
      ${getAvatarHTML(safeUsername, data.isHost)}
      <div style="line-height: 1.4; padding-top: 4px;">
        <span style="color:${data.isHost ? "#E50914" : "#4CAF50"}; font-weight:bold;">${safeUsername}:</span> 
        <span style="color:#eee; word-break: break-word;">${safeText}</span>
      </div>
    </div>`;
        mDiv.scrollTop = mDiv.scrollHeight;

        if (isSidebarHidden) spawnMarquee(safeUsername, safeText, data.isHost);
      }

      if (data.type === "SETTINGS_UPDATE") {
        controlMode = data.mode;
        addSysMsg(
          `Room control changed to: ${data.mode === "everyone" ? "Everyone" : "Host Only"}`,
        );
      }
    });
  }
}

// --- VIDEO SYNC LOGIC ---
function attachVideoListeners(video, activeSocket, isHost, username) {
  activeSocket.addEventListener("open", () => {
    activeSocket.send(
      JSON.stringify({ type: "JOIN", username: username, isHost: isHost }),
    );
  });

  if (isHost) {
    heartbeatInterval = setInterval(() => {
      if (activeSocket.readyState === WebSocket.OPEN) {
        activeSocket.send(
          JSON.stringify({
            type: "SYNC",
            time: video.currentTime,
            paused: video.paused,
          }),
        );
      }
    }, 2000);
  }

  let isIncomingEvent = false;
  const canControl = () => isHost || controlMode === "everyone";

  video.addEventListener("pause", () => {
    if (isIncomingEvent) return;
    if (!canControl()) {
      isIncomingEvent = true;
      if (!lastHostState.paused) video.play();
      setTimeout(() => (isIncomingEvent = false), 50);
      return;
    }
    activeSocket.send(
      JSON.stringify({ type: "PAUSE", time: video.currentTime }),
    );
  });

  video.addEventListener("play", () => {
    if (isIncomingEvent) return;
    if (!canControl()) {
      isIncomingEvent = true;
      if (lastHostState.paused) video.pause();
      setTimeout(() => (isIncomingEvent = false), 50);
      return;
    }
    activeSocket.send(
      JSON.stringify({ type: "PLAY", time: video.currentTime }),
    );
  });

  video.addEventListener("seeked", () => {
    if (isIncomingEvent) return;
    if (!canControl()) {
      isIncomingEvent = true;
      video.currentTime = lastHostState.time;
      setTimeout(() => (isIncomingEvent = false), 50);
      return;
    }
    activeSocket.send(
      JSON.stringify({ type: "SEEK", time: video.currentTime }),
    );
  });

  activeSocket.addEventListener("message", (event) => {
    const data = JSON.parse(event.data);

    if (data.type === "SETTINGS_UPDATE") {
      controlMode = data.mode;
    }

    if (["PAUSE", "PLAY", "SEEK", "SYNC"].includes(data.type)) {
      isIncomingEvent = true;
      if (data.type === "SYNC") {
        lastHostState = { time: data.time, paused: data.paused };
        if (Math.abs(video.currentTime - data.time) > 2)
          video.currentTime = data.time;
        if (video.paused !== data.paused) {
          if (data.paused) video.pause();
          else video.play();
        }
      } else {
        if (data.type === "PAUSE") video.pause();
        if (data.type === "PLAY") video.play();
        if (
          data.type === "SEEK" &&
          Math.abs(video.currentTime - data.time) > 0.5
        )
          video.currentTime = data.time;
      }
      setTimeout(() => {
        isIncomingEvent = false;
      }, 50);
    }
  });
}

// --- INITIALIZATION ---
if (window.self === window.top) {
  chrome.storage.local.remove(["sk_room", "sk_user", "sk_host"]);
  const autoJoinRoom = new URLSearchParams(window.location.search).get(
    "sk_room",
  );
  if (autoJoinRoom) setTimeout(() => initSidebar(autoJoinRoom), 1000);
} else {
  const triggerIframeSync = (roomId, username, isHost) => {
    const checkVideo = setInterval(() => {
      const v = document.querySelector("video");
      if (v) {
        clearInterval(checkVideo);
        const frameSocket = new WebSocket(
          `ws://127.0.0.1:1999/parties/main/${roomId}`,
        );
        attachVideoListeners(v, frameSocket, isHost, username);
      }
    }, 1000);
  };

  chrome.storage.local.get(["sk_room", "sk_user", "sk_host"], (data) => {
    if (data.sk_room)
      triggerIframeSync(data.sk_room, data.sk_user, data.sk_host);
  });

  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.sk_room && changes.sk_room.newValue) {
      triggerIframeSync(
        changes.sk_room.newValue,
        changes.sk_user?.newValue || "Guest",
        changes.sk_host?.newValue || false,
      );
    }
  });
}
