chrome.action.onClicked.addListener((tab) => {
  // Send a signal to the active tab to toggle the sidebar
  chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_SIDEBAR" });
});