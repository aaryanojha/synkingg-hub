// auth-bridge.js - This runs ONLY on your Next.js site

// Wait for the user to log in (Assuming your Next.js site saves info to localStorage or a global variable)
// If you use Clerk, it saves a cookie, but you can also expose user data to the window object in Next.js.
setInterval(() => {
  // Example: Checking if your Next.js site put the user data in localStorage
  const userDataString = localStorage.getItem('synkingg_user'); 
  
  if (userDataString) {
    const user = JSON.parse(userDataString);
    
    // Save it to Chrome's Extension Storage
    chrome.storage.local.set({ 
      sk_token: user.token,
      sk_username: user.name,
      sk_avatar: user.avatarUrl 
    }, () => {
      // Optional: Auto-close the tab once the extension has the data
      console.log("SynKingg Extension grabbed the auth data!");
      // window.close(); 
    });
  }
}, 1000);